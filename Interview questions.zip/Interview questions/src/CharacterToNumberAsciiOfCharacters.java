import java.util.Scanner;

public class CharacterToNumberAsciiOfCharacters {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING ");
		String s=ip.nextLine();
		StringBuilder sb=new StringBuilder();
		for(int i=0;i<s.length();i++)
		{
			int num = 0,num1=0;
			num=(num*10)+(s.charAt(i)-'0');
			System.out.println( "ASCII VALUE   "+s.charAt(i)+" "+ num);
			
			
			
			num1=(num1*10)+(s.charAt(i)-'a');
			System.out.println("POSITION  "+s.charAt(i)+"   "+ num1);
		}
		
			
	}

}
