//aaabbc
//a2b2c1


import java.util.Scanner;

public class StringCompression {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str=ip.nextLine();
		int i,j;
		int count;
		char[] ch=new char[10];
		int freq[]=new int[10];
		for(i=0;i<str.length();i++)
		{
			ch[i]=str.charAt(i);
			freq[i]=-1;
		}
		for(i=0;i<ch.length;i++)
		{
			count=1;
			for(j=i+1;j<ch.length;j++)
			{
				if(ch[i]==ch[j])
				{
					count++;
					freq[j]=0;
				}
			}
		
		if(freq[i]!=0)
		{
			freq[i]=count;
		}
		}
		for(i=0;i<ch.length;i++)
			
		{
		if(freq[i]!=0)
			System.out.print(ch[i]+""+freq[i]);
		}
	}

}
