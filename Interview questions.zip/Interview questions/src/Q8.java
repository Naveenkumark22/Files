import java.util.*;
import java .util.Scanner.*;
public class Q8 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER TOTAL");
		int total=ip.nextInt();
		int i ,j;
		int count=0;
		for(i=1;i<=6;i++)
		{
			for(j=1;j<=6;j++)
			{
				if(i+j==total)
				count++;	
			}
		}
		System.out.println(count);
				
	}

}
