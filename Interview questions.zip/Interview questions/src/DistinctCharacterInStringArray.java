import java.util.Scanner;

public class DistinctCharacterInStringArray {

	public static void main(String[] args) {
		
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		 String[] words = new String [size];
		System.out.println("ENTER THE ELEMENTS");
		 for(int i=0;i<size;i++)
		 {
			 words[i]=ip.next();
		 }
		 System.out.println("ENTER ALLOWED STRING");
		 
		 String allowed=ip.next();
		 
		
	        int c=0;
	        int distinct=0;
	        int nondistinct=0;
	        
	        for(int i=0;i<words.length;i++)
	        {
	            if(words[i].contains(allowed))
	            {
	            
	                //System.out.println(words[i]);
	                String str=new String();
	                str=words[i];
	              //  System.out.println(str);
	                for(int k=0;i<str.length()-2;k++)
	                {
	                	for(int q=k+1;q<str.length()-1;q++)
	                	{
	                		if(str.charAt(k)==str.charAt(q))
	                			c++;
	                			
	                			
	                	}
	                }
	                if(c==0)
	                	distinct++;
	                
	           //["cc","acd","b","ba","bac","bad","ac","d"]     
	            }
	        }
	        System.out.println("DISTINCT   " +distinct);
	        System.out.println("NONDISTINCT   " +(size-distinct));
	}

}



//ENTER THE SIZE
//5
//ENTER THE ELEMENTS
//qwe
//wer
//tyu
//dfg
//asdf
//ENTER ALLOWED STRING
//er
//wer
//DISTINCT   1
//NONDISTINCT   1

