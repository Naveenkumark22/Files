import java.util.Scanner;

public class PushZerosToEnd {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int count=0;
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ELEMENTS");
		int ar[]=new int[size];
		for(int i=0;i<size;i++)
		{
			ar[i]=ip.nextInt();
		}
		
		for(int i=0;i<ar.length;i++)
		{
			if(ar[i]!=0)
			{
				ar[count++]=ar[i];
				
			}
		}
			while(count<ar.length)
			{
				ar[count++]=0;
			}
			    
		for(int i=0;i<ar.length;i++)
		{
			System.out.println(ar[i]);
		}

	}

}



//
//ENTER THE SIZE
//5
//ENTER ELEMENTS
//1 0 3 0 5
//1
//3
//5
//0
//0
