import java.util.Scanner;
//the sky is blue 
//output  : blue is sky the
public class ReverseWords {

	public static void main(String[] args) {
		int i,j;
		Scanner ip=new Scanner(System.in);
		String str=ip.nextLine();
		String rev="";
		int start=str.length()-1;
		for(i=str.length()-1;i>=0;i--)
		{
			if(str.charAt(i)==' ')
			{
				
				for(j=i+1;j<=start;j++)
					System.out.print(str.charAt(j));
				System.out.print(" ");
				start=i-1;
					
			}
			if(i==0)
			{
				for(j=i;j<=start;j++)
				{
					System.out.print(str.charAt(j));
				}
			}
			
		}
		

	}

}
