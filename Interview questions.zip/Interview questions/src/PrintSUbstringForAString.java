//To print substring in a string
//INPUT----ABC
//OUTPUT---->
//A
//AB
//ABC
//ABCD
//B
//BC
//BCD
//C
//CD
//D
import java.util.Scanner;

public class PrintSUbstringForAString {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING");
		String str=ip.nextLine();
		int i,j,k;
		String res="";
		for(i=0;i<str.length();i++)
		{
			for(j=i+1;j<=str.length();j++)
			
			{
//				for(k=i;k<j;k++)
//				{
//					res+=str.charAt(k);
//					      //System.out.print(str.charAt(k));
//				}
//				System.out.println(res);
//				res="";
//				         //System.out.println();
				
				
				 System.out.print(str.substring(i,j));
				
				
			}
			
			
			
		}

	}

}

//asdf
//a
//as
//asd
//asdf
//s
//sd
//sdf
//d
//df
//f
