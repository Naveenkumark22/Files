import java.util.*;
import java.util.Scanner.*;
public class Q5 {
	public static void main(String args[])
	{
		Scanner ip=new Scanner(System.in);
		int[] a=new int[10];
		int[] b=new int[10];
		int i;
		int sum=0;
		System.out.println("ENTER SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ARRAY1");
		for(i=0;i<size;i++)
		{
			a[i]=ip.nextInt();
		}
		System.out.println("ENTER ARRAY2");
		for(i=0;i<size;i++)
		{
			b[i]=ip.nextInt();
		}
		for(i=0;i<size;i++)
		{
			//to calculate sum of products
			sum=sum+a[i]*b[size-i-1];
		}
		System.out.println("ANSWER");
		System.out.println(sum);
	}

}
