import java.util.Scanner;

public class FirstAndLastDigitOfNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE NUMBER");
		int num=ip.nextInt();
		
		
		int  firstdigit,lastdigit;
		lastdigit=num%10;
		int tensposition;
		tensposition=(num/10)%10;
		while(num>=10)
		{
			num/=10;
		}
		firstdigit=num;
		
		System.out.println("FIRST DIGIT " + firstdigit);
		System.out.println("LAST DIGIT  "+ lastdigit);
		System.out.println("TENS POSITION "+tensposition); 
	}

}
