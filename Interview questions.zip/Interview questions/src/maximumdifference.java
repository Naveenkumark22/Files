import java.util.*;
//impo
public class maximumdifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int size;
		System.out.println("ENTER SIZE");
		size =s.nextInt();
		int arr[]=new int[size];
		System.out.println("ENTER ARRAY ELEMENTS");
		
		for(int i=0;i<size;i++)
			arr[i]=s.nextInt();
		
		int dif, max=0;
		for(int i=0;i<size-1;i++) {
		for(int j=0;j<size;j++)
		{
			dif=Math.abs(arr[i]-arr[j]);
			if(dif>max) 
				max=dif;
			
			}
		}
		System.out.println("OUTPUT");
		
		System.out.println(max);
	}

}
