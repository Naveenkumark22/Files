package Leetcode;

import java.util.Arrays;
import java.util.Scanner;

public class MeanTrim {

	public static void main(String[] args) {
	    Scanner ip=new Scanner(System.in);
	       int n=ip.nextInt();
	       int arr[]=new int[n];
	       String s="";
	       for(int i=0;i<n;i++)
	       {
	           arr[i]=ip.nextInt();
	          
	       }
	       
	       int k=(int)arr.length*1/20;
	        double sum=0;
	        double c=0;
	        Arrays.sort(arr);
	        for(int i=k;i<arr.length-k;i++)
	        {
	            sum=sum+arr[i];
	            c++;
	        }
	        double avg=sum/c;
	        System.out.println(avg);
	}

}
