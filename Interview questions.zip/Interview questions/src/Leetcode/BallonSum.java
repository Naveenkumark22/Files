package Leetcode;

import java.util.Scanner;

public class BallonSum {

	public static void main(String[] args) {
		
		 
	       Scanner ip=new Scanner(System.in);		
	String text=ip.nextLine();
	 int arr[]=new int[5];
     for(int i=0;i<text.length();i++)
     {
         Character c=text.charAt(i);
         if(c=='b')
             arr[0]++;
         else if(c=='a')
         {
             arr[1]++;
         }
         else if(c=='n')
         {
             arr[2]++;
         }
         else if(c=='l')
         {
             arr[3]++;
         }else if(c=='o')
         {
             arr[4]++;
         }
     }
     
     arr[3]=arr[3]/2;
     arr[4]=arr[4]/2;
     int min=Integer.MAX_VALUE;
     for(int i=0;i<arr.length;i++)
     {
         min=Math.min(arr[i],min);
     }
     System.out.println(min);
     
	}

}



// q no  ------>1189