package Leetcode;

import java.util.Scanner;

public class ReformatNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		  
		  String number=ip.nextLine();
	       String s="";
	        String num="";
	        for(int i=0;i<number.length();i++)
	        {
	            if(Character.isDigit(number.charAt(i)))
	                num=num+number.charAt(i);
	        }
	        System.out.println(num);
	         while(num.length()>4)
	           
	       {
	           s=s+num.substring(0,3);
	             s=s+"-";
	           num=num.substring(3);
	           
	       }
	                System.out.println(num);
	        if(num.length()==4)
	        {
	            s=s+num.substring(0,2);
	            
	             s=s+"-"+num.substring(2,4);
	            
	        }
	        else
	        {
	             s=s+num;
	        }

	        
	        
	        System.out.println(s);
	}

}



//Q.NUMBER--->1694
