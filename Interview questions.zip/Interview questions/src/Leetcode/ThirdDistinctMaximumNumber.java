package Leetcode;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

public class ThirdDistinctMaximumNumber {

	public static void main(String[] args) {
	
		 Scanner ip=new Scanner(System.in);
	       int n=ip.nextInt();
	       int nums[]=new int[n];
	       String s="";
	       for(int i=0;i<n;i++)
	       {
	           nums[i]=ip.nextInt();
	          
	       }
	
		
		TreeSet<Integer> t=new TreeSet<Integer>();
        for(int i=0;i<nums.length;i++)
        {
            t.add(nums[i]);
        }
        int c=0;
        ArrayList<Integer> al=new ArrayList<Integer>(t);
        if(al.size()<3)
        {
         System.out.println(al.get(al.size()-1));
        }
        else if(al.size()>=3)
        {
            System.out.println(al.get(al.size()-3));
        }
	}	

}





//q no-> 414
