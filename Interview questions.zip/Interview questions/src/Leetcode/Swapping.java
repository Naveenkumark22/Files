package Leetcode;

import java.util.ArrayList;
import java.util.Scanner;

public class Swapping {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int n=ip.nextInt();
		ArrayList<Integer> al=new ArrayList<>();
		ArrayList<Integer> ans=new ArrayList<>();
	
		for(int i=0;i<n;i++)
		{
			al.add(ip.nextInt());
		}
		int key=ip.nextInt();
		for(int i=key;i<n;i++)
		{
			ans.add(al.get(i));
		}
		for(int i=0;i<key;i++)
		{
			ans.add(al.get(i));
		}
		System.out.println(ans);

	}

}
