package Leetcode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class Practice {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int n=ip.nextInt();
		ip.nextLine();
		String arr[]=new String[n];
		int num[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=ip.nextLine();
			num[i]=ip.nextInt();
			
			
		}
		ArrayList<String> al=new ArrayList<String>(Arrays.asList(arr));
		ArrayList<Integer> p=new ArrayList<Integer>();
		//Collections.addAll(p, num);
		System.out.println(al);
	}

}
