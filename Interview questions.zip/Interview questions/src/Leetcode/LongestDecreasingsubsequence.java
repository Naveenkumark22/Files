package Leetcode;

import java.util.Scanner;

public class LongestDecreasingsubsequence {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int n=ip.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
			arr[i]=ip.nextInt();
		}
		int max=Integer.MIN_VALUE;
		for(int i=1;i<n;i++)
		{
			int c=1;
			while(i<arr.length-1 && arr[i]<arr[i-1])
			{
				c++;
				i++;
			}
			max=Math.max(max, c);
			
			
		}
		System.out.println(max);
	}

}
