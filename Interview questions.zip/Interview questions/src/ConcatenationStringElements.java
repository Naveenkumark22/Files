
public class ConcatenationStringElements {

}
