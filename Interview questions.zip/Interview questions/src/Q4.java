//LEADER ELEMENTS
//q4

import java.util.*;
import java.util.Scanner.*;
public class Q4 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int i,j;
		int s=0;
		int[] a=new int[10];
		System.out.println("ENTER SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ARRAY");
		for(i=0;i<size;i++)
		{
			a[i]=ip.nextInt();
		}
		for(i=0;i<size;i++)
		{
			for(j=i+1;j<size;j++)
			{
				if(a[i]<a[j])
					break;
			}
			if(j==size)
			{
				System.out.println("LEADER ELEMENTS");
				System.out.println(a[i]);
				s=s+a[i];
				
			}
		}
		System.out.println("leader sum");
		
		System.out.println(s);
		
	}

}
