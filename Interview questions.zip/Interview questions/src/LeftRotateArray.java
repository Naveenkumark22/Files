import java.util.Scanner;

public class LeftRotateArray {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ELEMENTS");
		int ar[]=new int[size];
		for(int i=0;i<size;i++)
		{
			
			ar[i]=ip.nextInt();
		}
		int temp;
		temp=ar[0];
		for(int i=1;i<size;i++)
		{
			ar[i-1]=ar[i];
		}
		ar[ar.length-1]=temp;
		for(int i=0;i<size;i++)
		{
			System.out.println(ar[i]);
		}
		
		}

}


//ENTER THE SIZE
//5
//ENTER ELEMENTS
//1 2 3 4 5
//2
//3
//4
//5
//1