//question 1


import java.util.*;
import java.util.Scanner;
public class Validpassword {

	 int find(int n,String str){
		int i,r = 0;
		boolean ans=true;
		boolean isnum=false;
		boolean iscap=false;
		if(str.length()<4)
		return 0;
		for(i=0;i<str.length();i++)
		{
			char ch0=str.charAt(0);
			char ch=str.charAt(i);
			
			if(ch0 >=48&&ch0<=57)
			{
				return 0;
			}
			else if(ch>=48&&ch<=57)
			{
			isnum=true;	
			}
			else if(ch>=65&&ch<=90)
			{
				iscap=true;
			}
			else if(ch==' '|| ch=='/' )
			{
				return 0;
			}
			
	}
		if(isnum&&iscap==true)
		{
			return 1;
		}
		else 
			return 0;
	
	}
	
	
	public static void main(String[] args) {
		int i;
	 Scanner s=new Scanner(System.in);
	 System.out.println("Enter size");
	 int n=s.nextInt();
	 System.out.println("Enter String");
	 String str=s.next();
	 Validpassword a=new Validpassword();
	int v= a.find(n, str);
	
	System.out.println(v);
	
	}		
	

}
