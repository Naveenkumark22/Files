import java.util.Scanner;

public class HowManyTimesRotation {

	public static void main(String[] args) {
		
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ELEMENTS");
		int ar[]=new int[size];
		for(int i=0;i<size;i++)
		{
			
			ar[i]=ip.nextInt();
		}
		System.out.println(" ENTER NUMBER OF TIMEWS TO ROTATE ");
		int n=ip.nextInt();
		int t=0;
		while(t<n)
		{
			int temp=ar[0];
			for(int i=1;i<ar.length;i++)
			{
				ar[i-1]=ar[i];	
				
			}
			ar[ar.length-1]=temp;
			t++;
			
		}
		for(int i=0;i<size;i++)
		{
			System.out.println(ar[i]);
		}
	}

}

//
//ENTER THE SIZE
//5
//ENTER ELEMENTS
//1 2 3 4 5
// ENTER NUMBER OF TIMEWS TO ROTATE 
//3
//4
//5
//1
//2
//3

