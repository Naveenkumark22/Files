import java.util.Scanner;

public class A3b2c3 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING");
		String s=ip.next();
		for(int i=1;i<s.length();i=i+2)
		{
			int n=Integer.parseInt(s.charAt(i)+"");
			for(int j=0;j<n;j++)
				
				System.out.print(s.charAt(i-1));
		}
	}

}
