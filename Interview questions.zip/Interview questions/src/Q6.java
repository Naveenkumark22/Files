//Q6
//MAXIMUM ELEMENT AND ITS POSITION

import java.util.*;
import java.util.Scanner.*;
public class Q6 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int i,j;
		int position=0;
		int max=0;
		int[] a=new int[10];
		System.out.println("ENTER SIZE");
		
		int size=ip.nextInt();
		System.out.println("ENTER ARRAY");
		for(i=0;i<size;i++)
		{
			a[i]=ip.nextInt();
		}
		for(i=0;i<size;i++)
		{
			if(a[i]>max)
				max=a[i];
			 position=i;
		}
		System.out.println("MAXIMUM ELEMENT ");
		System.out.println(max);
		System.out.println(" POSITION OF MAX ELEMENT");
		System.out.println(position);
	}

}
