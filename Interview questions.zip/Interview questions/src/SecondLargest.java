import java.util.*;
public class SecondLargest {
	public static void main(String args[])
	   {
	       int max,secondmax, len, i;
	       int arr[] = new int[200];
	       Scanner scan = new Scanner(System.in);
		   
	       System.out.print("Enter Length of the array : ");
	       len = scan.nextInt();
		   
	       System.out.print("Enter elements in the array : ");
	       for(i=0; i<len; i++)
	       {
	           arr[i] = scan.nextInt();
	       }
		  
	       max = arr[0];
		   secondmax=arr[1];
		  
	       for(i=0; i<len; i++) 
	       {
	    	   //TO STORE MAX   only maximum array elements enter
	           if(max < arr[i])  
	           {
	        	   secondmax=max;
	               max = arr[i];
	           }
	           //TO STORE SECONDMAX VALUE
	           else if(arr[i]>secondmax && arr[i]<max) 
	        	   secondmax=arr[i];
	           
	       } 
		   
	       System.out.print("Largest Element of the array is = "+ secondmax); 
	   }

}
