import java.util.Scanner;

public class RemovingOuterParantheses {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE  PARANTHESES STRING");
		String str=ip.next();
		int count=0;
		String res="";
		for(int i=0;i<str.length();i++)
		{
			
			//for ')' c--  
			if(str.charAt(i)==')')
				count--;
			if(count!=0)
				res+=str.charAt(i);
			
			//for '(' c++
			if(str.charAt(i)=='(')
				count++;
		}
		System.out.println(res);
	}

}


