//question 2
//difference
import java.util.*;
import java.util.Scanner.*;
import java.lang.Math;
public class Findcount {
    int count(int arr[], int length,int num,int dif)
    {
    	int i,count=0;
    	for(i=0;i<length;i++)
    	{
    		if(Math.abs((arr[i]-num))<dif)
    		{
    			count++;
    		}
    	}
    	return count;
    }
	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int i;
		int[] arr=new int[10];
		System.out.println("Enter length");
		int length=ip.nextInt();
		System.out.println("Enter array");
		for(i=0;i<length;i++)
		{
			arr[i]=ip.nextInt();
		}
		System.out.println("Enter num");
		int num=ip.nextInt();
		System.out.println("Enter diff");
		int dif=ip.nextInt();
		Findcount a=new Findcount();
		int res=a.count(arr, length, num, dif);
		System.out.println(res);
	}

}
