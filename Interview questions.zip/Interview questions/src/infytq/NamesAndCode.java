package infytq;

import java.util.ArrayList;
import java.util.Scanner;

public class NamesAndCode {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			String str=ip.next();
			ArrayList<String> names=new ArrayList<String>();
			ArrayList<String> codes=new ArrayList<String>();
			String[] input=str.split(",");
			for(int i=0;i<input.length;i++)
			{
				String s=input[i];
				String[] inner=s.split(":");
				names.add(inner[0]);
				codes.add(inner[1]);
			}
			System.out.println(names);
			System.out.println(codes);
			
			for(int i=0;i<names.size();i++)
			{
				String name=names.get(i);
				String code=codes.get(i);
				int  namelength=name.length();
				for(int j=0;j<code.length();j++)
				{
					int n=Integer.parseInt(code.charAt(j)+" ");
					if(n<namelength)
					{
						int index=j;
					}
							
				}
			}
			
	}

}
