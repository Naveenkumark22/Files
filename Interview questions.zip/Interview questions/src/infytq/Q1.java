package infytq;

import java.util.Scanner;

public class Q1 {

	public static void main(String[] args) {
		
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE THE STRING");
		String s=ip.next();
		int target1=4;
		int target2=7;
		int t1=0,t2=0;
		String[] str=s.split(",");
		int arr[]=new int[str.length];
		for(int i=0;i<str.length;i++)
		{
			arr[i]=Integer.parseInt(str[i]);
			if(target1==arr[i])
				t1=i;
			if(target2==arr[i])
				t2=i;
	//	System.out.println(str[i]);
		}
		//System.out.println(t1);
		//System.out.println(t2);
		int sum1=0;
		String sum2="";
		for(int i=0;i<arr.length;i++)
		{
			if(i>=t1&i<=t2)
			{
				
				String sq=String.valueOf(arr[i]);	
				sum2=sum2+sq;
			}
			
			else
				sum1+=arr[i];
			
		}
		int sum3=Integer.parseInt(sum2);
		int sum=sum1+sum3;
		System.out.println("ANSWER");
		
		System.out.println(sum);
	
	}
	
}
