package infytq;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Q4LargestEvenNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE THE STRING");
		String s=ip.next();
		ArrayList<Integer>  a=new ArrayList<Integer>();
		for(int i=0;i<s.length();i++)
		{
			char str=s.charAt(i);
			if(Character.isDigit(str))
			{
				int n=Integer.parseInt(s.charAt(i)+"");
				a.add(n); //adding to list 
			}
		}
		
		Collections.sort(a);       //now sorting list
		System.out.println(a);     //printing list
		String num="";//string 
		int presentonce=0;
		for(int i=a.size()-1;i>=0;i--)
		{
			num=num+a.get(i);       //concatenating and making  as string 
			//System.out.println(num);
			if(a.get(i)%2==0)
			{
				presentonce++;
			}
		}
		//System.out.println(a);
		if(presentonce==0)
		{
			System.out.println("-1");
		}
		int ans=Integer.parseInt(num); //converting string too num
		if(ans%2==0)
			System.out.println(ans);
		
		
		
	
		else if(presentonce>0)
	{
			String num1="";
			int last=0;
			for(int i=0;i<a.size();i++)
			{
				if(a.get(i)%2==0)
				{ 
					 last=a.get(i);
					  a.remove(i);
				//	System.out.println(last);
					break;
				}
			}
			System.out.println(a);
		//	a.add(last);
			for(int i=a.size()-1;i>=0;i--)
			{
				 num1=num1+a.get(i);
				//System.out.println(num);
			}
			num1=num1+last;
			System.out.println(num1);
			//System.out.println(a);
			int ans1=Integer.parseInt(num1);
     	//	if(ans1%2==0)
				System.out.println(ans1);
	}
		
	}

}
