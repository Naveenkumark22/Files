package infytq;

import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE THE STRING");
		int num=ip.nextInt();
		String s=String.valueOf(num);
		System.out.println();
		String ans="";
		for(int i=0;i<s.length();i++)
		{
			int sq=0;
			if(i%2!=0)
			{
				int n=Integer.parseInt(s.charAt(i)+"");
				sq=n*n;
				String square=String.valueOf(sq);
				ans=ans+square;
				
			}
		}
		System.out.println(ans);
		int otp=Integer.parseInt(ans.substring(0, 4));
		System.out.println(otp);
	}

}
