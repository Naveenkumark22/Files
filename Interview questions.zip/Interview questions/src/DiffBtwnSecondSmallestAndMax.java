//ENTER THE SIZE
//5
//1 2 3 4 5
// MAXIMUM ELEMENT  5
//SECOND  MAXIMUM ELEMENT  4
// MINIMUM  ELEMENT  1
//ANSWER
//3







import java.util.Scanner;
public class DiffBtwnSecondSmallestAndMax{
    public static void main(String[] args) {
        int size,max=0,min=0;
        int max2 = 0;
        System.out.println("ENTER THE SIZE");
         Scanner s = new Scanner(System.in);
         size = s.nextInt();
         int[] a = new int[size];
         for(int i=0;i<size;i++){
            a[i] = s.nextInt();
        }
         if(size>2){
             max2 = 0;
             
         }
         max = a[0];
         min = a[0];
         for (int j = 0; j < size; j++) {
             if(a[j]>max){
                 max2 = max;
                 max=a[j];
               }
             //for finding max2
             if(a[j]>max2 && a[j]<max){
                 max2=a[j];
             }
             if(a[j]<min){
                 min = a[j];
             }
         }
         System.out.println(" MAXIMUM ELEMENT  "+max);
         System.out.println("SECOND  MAXIMUM ELEMENT  "+max2);
         System.out.println(" MINIMUM  ELEMENT  "+min);
         System.out.println("ANSWER");
         System.out.println(max2-min);        
        s.close();
    }
}