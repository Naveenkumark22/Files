import java.util.Scanner;

public class ReverseWordsInString {

	public static void main(String[] args) {
		int i,j;
		System.out.println("ENTER THE STRING");
		Scanner ip=new Scanner(System.in);
		String str=ip.nextLine();
		String rev="";
		int start=0 ,wordcount=0;
		for(i=0;i<str.length();i++)
		{
			if(str.charAt(i)==' ')
			{
				wordcount++;			//TO COUNT NUMBER OF WORDS
				for(j=i-1;j>=start;j--)
				{
					System.out.print(str.charAt(j));
				}
				System.out.print(' ');
				start=i+1;
			}
			
			if(i==str.length()-1)
			{
				for(j=i;j>=start;j--)
				{
					System.out.print(str.charAt(j));
				}
					
			}
		}
		
	
	//	System.out.println(wordcount+1);  ///TO PRINT WORDCOUNT
	}

}
