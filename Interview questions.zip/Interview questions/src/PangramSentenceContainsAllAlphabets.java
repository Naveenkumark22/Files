import java.util.Scanner;

public class PangramSentenceContainsAllAlphabets {

	public static void main(String[] args) {
		  Scanner ip=new Scanner(System.in);
		  System.out.println("ENTER THE STRING");
		  String s=ip.next();
		  int c=0;
		  String a="abcdefghijklmnopqrstuvwxyz";
		  for(int i=0;i<a.length();i++)
		  {
			  if(!s.contains(Character.toString(a.charAt(i))))
				 c++;
				  
				  
		  }
		  if(c==0)
			System.out.println("yes"); 
		  else
			  System.out.println("no");
	}

}

