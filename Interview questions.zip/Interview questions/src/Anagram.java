import java.util.*;
public class Anagram{
public static void main(String args[])
{
    Scanner ip=new Scanner(System.in);
    String str1=ip.nextLine();
    String str2=ip.next();

    char[] ch1=str1.toCharArray();
    
   char[] ch2=str2.toCharArray();
int len1=ch1.length;
  int len2=ch2.length;
   

    char temp,temp1;
    for(int i=0;i<len1;i++)
    {
        for(int j=0;j<len1;j++)
        {
            if(ch1[i]<ch1[j])
            {
            temp=ch1[i];
            ch1[i]=ch1[j];
            ch1[j]=temp;
            }
           
        }
    }

     for(int i=0;i<len2;i++)
    {
        for(int j=0;j<len2;j++)
        {
            if(ch2[i]<ch2[j])
            {
            temp1=ch2[i];
            ch2[i]=ch2[j];
            ch2[j]=temp1;
            }
           
        }
    }


     int c=0;
    for(int i=0;i<len2;i++)
    {
        if(ch1[i]!=ch2[i])
        c=1;
       
    }
  if(c==0)
    System.out.println("Strings are anagram");
    else
      System.out.println("Strings are not anagram");
}
}
