
public class MaximumDiffInArrayInIncreasingOrder {

	public static void main(String[] args) {
		class Solution {
		    public int maximumDifference(int[] nums) {
		        int size=nums.length;
		        int max=-1,dif;
		        for(int i=0;i<size;i++)
		        {
		            for(int j=i+1;j<size;j++)
		            {
		                if(nums[i]<nums[j])
		                {
		                    dif=nums[j]-nums[i];
		                    if(dif>max)
		                        max=dif;
		                    
		                }
		            }
		}
		return max;
		        
		    }
		}

	}

}
