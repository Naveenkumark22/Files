//JUST FOR HOW TO PASSING ARGUMENTS AND RETURN IT

import java.util.*;
import java.util.Scanner.*;

public class Q9 {
	String greeting(String s){
		return "Hello "+s;
		
	}

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER STRING");
		String s=ip.next();
		Q9 a=new Q9();
		String ans=a.greeting(s);
		System.out.println(ans);
		

	}

}
