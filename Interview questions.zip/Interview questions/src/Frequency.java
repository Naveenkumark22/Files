import java.util.Arrays;
import java.util.Scanner;

public class Frequency {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		
		String s=sc.next();
		int freq[]=new int[26];
		
		for(int i=0;i<s.length();i++)
		{
			freq[s.charAt(i)-'a']++;
		}
		
	//	System.out.println(Arrays.toString(freq));
		
		for(int i=0;i<freq.length;i++)
		{
			if(freq[i]!=0)
			{
				System.out.println((char)(i+'a')+" "+freq[i]);
			}
		}
	}

}
