package Hashmap;

import java.util.LinkedHashMap;
import java.util.Scanner;

public class MaximumSubstring {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String s=ip.nextLine();
		String word=ip.nextLine();
		LinkedHashMap<String,Integer> hm=new LinkedHashMap<>();
        if(s.length()==word.length())
        {
            if(s.equals(word))
              //  return 1;
            	System.out.println("1");
        }
        for(int i=0;i<s.length();i++)
        {
            for(int j=i;j<s.length();j++)
            {
                String sub=s.substring(i,j);
               System.out.println(sub);
                
                hm.put(sub,hm.getOrDefault(sub,0)+1);

                    
            }
        }
        //System.out.println(hm.get(word));
        System.out.println(hm);
        if(hm.containsKey(word))
        System.out.println(hm.get(word));
	}

}
