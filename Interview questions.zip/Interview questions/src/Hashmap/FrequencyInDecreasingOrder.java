package Hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class FrequencyInDecreasingOrder {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		LinkedHashMap<Integer,Integer> hm=new LinkedHashMap<>();
		System.out.println("ENTER SIZE:");
		int n=ip.nextInt();
		for(int i=0;i<n;i++)
		{
			
			int num=ip.nextInt();
			//if(hm.containsKey(n))
			hm.put(num, hm.getOrDefault(num, 0)+1);
			
		}
		System.out.println(hm);
		ArrayList<Integer> al=new ArrayList<>(hm.keySet());
		ArrayList<Integer> freq=new ArrayList<>(hm.values());
		
		int max=Collections.max(freq);
		for(int i=max;i>=1;i--)
		{
			
			for(int j=0;j<freq.size();j++)
			{
				int value=freq.get(j);
				if(i==value)
				{
					for(int k=0;k<i;k++)
					{
						System.out.print(al.get(j)+" ");
					}
				}
			}
		}
	}
}
