package Hashmap;

import java.util.HashMap;
import java.util.Scanner;
import java.util.TreeMap;

public class Basic {

	public static void main(String[] args) {
		 Scanner ip=new Scanner(System.in);
		  int n=ip.nextInt();
		  
		  HashMap<String,Integer> h=new HashMap<>();
	       String arr[]=new String[n];
	      
	       for(int i=0;i<n;i++)
	       {
	           arr[i]=ip.next();
	           if(!h.containsKey(arr[i]))
	           {
	        	   h.put(arr[i], 0);
	           }
	          
	           if(h.containsKey(arr[i]))
	           {
	        	   int freq=h.get(arr[i]);
	        	   h.replace(arr[i], freq+1);
	           }
	       }
	       
	       TreeMap<String, Integer> sorted = new TreeMap<>();
	       
	        // Copy all data from hashMap into TreeMap
	        sorted.putAll(h);
	        System.out.println(sorted);
	        
		 
	}

	
	
}
