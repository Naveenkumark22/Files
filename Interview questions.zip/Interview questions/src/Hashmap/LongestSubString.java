package Hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class LongestSubString {
	
	
	public static boolean check(String str) {
		Set<Character> set=new HashSet();
		List<Character> list=new ArrayList();
		for(int i=0;i<str.length();i++) {
			set.add(str.charAt(i));
			list.add(str.charAt(i));
		}
		List<Character> res=new ArrayList(set);
		Collections.sort(res);
		Collections.sort(list);
		if(res.toString().equals(list.toString()))
			return true;
		return false;
	}
	
	
	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str=ip.next();
		int max=-100;
		for(int i=0;i<str.length();i++) {
			StringBuilder sb=new StringBuilder();
			for(int j=i;j<str.length();j++) {
				sb.append(str.charAt(j));
				System.out.println(sb.toString());
				
				
				if(check(sb.toString())) {
					max=Math.max(max, sb.length());
				}
			}
		}
		System.out.print(max);
	}

}