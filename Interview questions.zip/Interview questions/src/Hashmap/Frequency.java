package Hashmap;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class Frequency {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String s=ip.nextLine();
		HashMap<Character,Integer> hm=new HashMap<>();
		
		for(int i=0;i<s.length();i++)
		{
			char c=s.charAt(i);
			
			hm.put(c, hm.getOrDefault(c, 0)+1);
			
		}
		
		
		//storing keys
		ArrayList<Character> al=new ArrayList<>(hm.keySet());
		ArrayList<Integer> freq=new ArrayList<>();
		Collections.sort(al);
		for(int i=0;i<al.size();i++)
		{
			int f=hm.get(al.get(i));
			freq.add(f);
		}
		
		System.out.println(al);
		System.out.println(freq);
		
		

	}

}
