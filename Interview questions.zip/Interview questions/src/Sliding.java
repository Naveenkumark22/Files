import java.util.Scanner;

public class Sliding {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER SIZE");
		int size=ip.nextInt();
		int a[]=new int[size];
		for(int i=0;i<size;i++)
		{
			a[i]=ip.nextInt();
		}
		int sum=0,max=0;
		System.out.println("ENTER THE CONTINUOUS");
		int k=ip.nextInt();
		
		
		for(int i=0;i<=size-k;i++)
		{
			sum=0;
			for(int j=0;j<k;j++)
			{
				sum+=a[i+j];
				if(sum>max)
					max=sum;
			}
		}
		System.out.println(max);
		
		

	}

}
