
public class A1 {

	public static void main(String[] args) {
		
// int--->string	
		int i=10;  
		String s=String.valueOf(i);	 
		
// string-->character array       char[] num_str = str.toCharArray();
		
//CHARACTER ARRAY---->STRING   String s = new String(num_str);
		
		
// string-->integer             int num=Integer.parseInt(string);
//   character to string--->      String s=Character.toString(c);
		
//*****character to string----->	String s = Character.toString(word.charAt(i));
		
		//split using deliiter(space)
		//str="how are you"
		//String[] s=str.split(' ')  ---->string array
		
		//TO GET CHARACTER 
		//CHAR C=ip.next().charAT(0);
		
		
		
		//trim   ----->to remove first and last spaces
		// String s=str.trim();
		
		
		//MATRIX
		//row length=size of array
		//columnln length=arr[0].length;
		
		//decimal to binart---->Integer.to binaryString
		
	}

}
