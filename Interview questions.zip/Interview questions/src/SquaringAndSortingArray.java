//SQUARE OF GIVEN ARRAY AND SORTING THE SQUARED ARRAY

import java.util.Scanner;

public class SquaringAndSortingArray {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int size=ip.nextInt();
		int[] a=new int[size];
		int i,j;
		for(i=0;i<size;i++)
		{
			a[i]=ip.nextInt();
		}
		int square;
		int[] sq=new int[size];
		for(i=0;i<size;i++)
		{
			square=Math.abs(a[i]*a[i]);
			sq[i]=square;
		}
		int temp;
		for(i=0;i<size;i++)
		{
			for(j=i+1;j<size;j++)
			{
				if(sq[i]>sq[j])
				{
					temp=sq[i];
					sq[i]=sq[j];
					sq[j]=temp;
					
					
				}
			}
		}
		for(i=0;i<size;i++)
		{
			System.out.println(sq[i]);
		}
	}

}
