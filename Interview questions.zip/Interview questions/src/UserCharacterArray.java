import java.util.Scanner;

public class UserCharacterArray {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			System.out.println("ENTER THE SIZE");
			int size=ip.nextInt();
			char ar[]=new char[size];
			System.out.println("ENTER ELEMENTS");
			for(int i=0;i<size;i++)
			{
			ar[i]=ip.next().charAt(0);
			}
			for(int i=0;i<ar.length;i++)
			System.out.println(ar[i]);
			
	}

}
