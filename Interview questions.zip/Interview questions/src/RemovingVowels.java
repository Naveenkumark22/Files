import java.util.*;
public class RemovingVowels{
    public static void main(String args[])
    {

        Scanner ip=new Scanner(System.in);
        String str=ip.nextLine();
        String s="";

for(int i=0;i<str.length();i++)
{
    if(str.charAt(i)!='a'&&str.charAt(i)!='e'&&str.charAt(i)!='i'&&str.charAt(i)!='o'&&str.charAt(i)!='u'&&str.charAt(i)!='A'&&str.charAt(i)!='E'&&str.charAt(i)!='I'&&str.charAt(i)!='O'&&str.charAt(i)!='U'&&str.charAt(i)!=' ')
    
    {
    System.out.print(str.charAt(i));
}
}
//ANOTHER METHOD
//if(str.charAt(i)=='a'&&str.charAt(i)=='e)
//{
//		
//}
//else
//	System.out.println(str.charAt(i));
    
    }
}