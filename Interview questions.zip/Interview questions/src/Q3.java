import java.util.*;
import java.util.Scanner;
import java.lang.*;

public class Q3 {
	
	char and(char ans,char ans2)
	{
		if(ans=='1' && ans2=='1')
			return '1';
		return'0' ;
		
	}
	char or(char ans,char ans2)
	{
		if(ans=='0' && ans2=='0')
			return '1';
		return '0';
		
	}
	char xor(char ans,char ans2)
	{
		if(ans==ans2)
			return '0';
		return '1';
		
	}
	
	int helper(String s) throws Exception
	{
	char ans=s.charAt(0);
	 int i;
	 for(i=1;i<s.length();i=+2)
	 {
		 char operation=s.charAt(i);
		 char ans2=s.charAt(i+1);
		 if(operation=='A')
		 {
			 ans=and(ans,ans2);
		 }
		 else if(operation=='B')
			 ans=or(ans,ans2);
		 else if(operation=='C')
			 ans=xor(ans,ans2);
	 }
	 return ans;
	}

	public static void main(String[] args) throws Exception 
	{
		Scanner ip=new Scanner(System.in);
		String s=ip.next();
		Q3 a=new Q3();
		 int res = a.helper(s);
		System.out.println(res);
		
	}

}
