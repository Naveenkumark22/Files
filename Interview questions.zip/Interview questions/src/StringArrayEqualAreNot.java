//class Main
//{
//    public static boolean checkEquality(String[] s1, String[] s2)
//    {
//        if (s1 == s2) {
//            return true;
//        }
// 
//        if (s1 == null || s2 == null) {
//            return false;
//        }
// 
//        int n = s1.length;
//        if (n != s2.length) {
//            return false;
//        }
// 
//        for (int i = 0; i < n; i++)
//        {
//            if (!s1[i].equals(s2[i])) {
//                return false;
//            }
//        }
// 
//        return true;
//    }
// 
//    public static void main(String[] args)
//    {
//        String[] s1 = { "A", "B", "C" };
//        String[] s2 = { "A", "B", "C" };
// 
//        if (checkEquality(s1, s2)) {
//            System.out.println("Both arrays are equal");
//        }
//        else {
//            System.out.println("Both arrays are not equal");
//        }
//    }
//}
//
//
//
//
//
//class Solution {
//    public boolean arrayStringsAreEqual(String[] word1, String[] word2) {
//        StringBuilder str= new StringBuilder();
//        StringBuilder str2= new StringBuilder();
//        
//        for (String j: word1)
//        {
//            str.append(j);
//        }
//        for (String i: word2)
//        {
//            str2.append(i);
//        }
//        
//        String word1_=str.toString();
//        String word2_= str2.toString();
//        if (word1_.equals(word2_))
//        {
//            return true;
//        }
//        return false;
//        
//    }
//}
//
//class Solution {
//    public boolean arrayStringsAreEqual(String[] word1, String[] word2) {
//      StringBuilder s1=new StringBuilder();
//        StringBuilder s2=new StringBuilder();
//        for(int i=0;i<word1.length;i++)
//        {
//            s1.append(word1[i]);
//        }
//        for(int j=0;j<word2.length;j++)
//        {
//            s2.append(word2[j]);
//        }
//        String st1=s1.toString();
//        String st2=s2.toString();
//        if(st1.equals(st2))
//            return true;
//        else 
//            return false;
//    }
//}
// 