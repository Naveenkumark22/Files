package String;

import java.util.Arrays;
import java.util.Scanner;

public class SortStringWords {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING ");
		String s=ip.nextLine();
	String[] str=s.split(" ");
		String temp;
		for(int i=0;i<str.length;i++)
		{
			
			 for(int j=i+1;j<str.length;j++)
			 {
				 if(str[i].length()>str[j].length())
				 {
					 temp=str[i];
					 str[i]=str[j];
					 str[j]=temp;
							 
				 }
			 }
		}
	
		for(int i=0;i<str.length;i++)
			System.out.print(str[i]+" ");
	
	
//USING INBUILT FUNCTION------>   Arrays.sort(str);
	}

}
