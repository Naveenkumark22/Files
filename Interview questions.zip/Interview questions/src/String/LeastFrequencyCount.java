package String;


import java.util.*;
class LeastFrequencyCount {
    public static void main(String args[] ) throws Exception {
       Scanner ip=new Scanner(System.in);
       
       
       int room1=ip.nextInt();
       int room2=ip.nextInt();
       int n=ip.nextInt();
       ArrayList<Integer> villages=new ArrayList<>();
       for(int i=0;i<n;i++)
       {
    	   villages.add(ip.nextInt());
       }
       Collections.sort(villages);
       System.out.println(villages);
       
       ArrayList<Integer> al=new ArrayList<>();
       ArrayList<Integer> bl=new ArrayList<>();
       int c1=0;
       int c2=0;
       int j=room1*villages.get(n-1);
       int k=0;
       al.add(villages.get(n-1));
       c1++;
       for(int i=n-2;i>=0;i--)
       {
    	   int x=j+(room1*villages.get(i));
    	   int y=k+(room2*villages.get(i));
    	   if(x<y)
    	   {
    		   al.add(villages.get(i));
    		   c1++;
    		   y=y-(room2*villages.get(i));
    		   if(x<y)
    		   {
    			   j=0;
    			   k=y-x;
    		   }
    		   else
    		   {
    			   k=0;
    			   j=x-y;
    		   }
    	   }
    	   else
    	   {
    		   x=x-(room1*villages.get(i));
    		   bl.add(villages.get(i));
    		   c2++;
    		   if(x<y)
    		   {
    			   j=0;
    			   k=y-x;
    		   }
    		   else
    		   {
    			   k=0;
    			   j=x-y;
    		   }
    	   }
       }
       System.out.println(al);
       System.out.println(bl);
       for(int i=0;i<c1;i++)
       {
    	   System.out.print(al.get(i)+" ");
       }
       System.out.println();
       for(int i=0;i<c2;i++)
       {
    	   System.out.print(bl.get(i)+" ");
       }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
//       int n=ip.nextInt();
//       int arr[]=new int[n];
//       String s="";
//       for(int i=0;i<n;i++)
//       {
//           arr[i]=ip.nextInt();
//          
//       }
//       TreeSet<Integer> t=new TreeSet<Integer>();
//        ArrayList<Integer> d=new ArrayList<Integer>();
//      for(int i=0;i<n;i++)
//      {
//          int num=arr[i];
//          while(num!=0)
//          {
//              int rem=Math.abs(num%10);
//
//                t.add(rem);
//                d.add(rem);
//                num=num/10;
//
//          }
//
//      }
//      ArrayList<Integer> freq=new ArrayList<Integer>();
//       ArrayList<Integer> tl=new ArrayList<Integer>(t);
//      int count=0;
//     for(int i=0;i<tl.size();i++)
//     {
//         for(int j=0;j<d.size();j++)
//         {
//             if(tl.get(i)==d.get(j))
//             {
//                    count++;
//             }
//         }
//         freq.add(count);
//         count=0;
//
//     }
//    //  System.out.println(tl);
//    //  System.out.println(freq);
//     int min=Collections.min(freq);
//     int index=freq.indexOf(min);
//     int element=tl.get(index);
//     System.out.println(element);


    }
}
