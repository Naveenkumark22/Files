package String;

import java.util.Scanner;

public class RemoveDuplicateInCharactersInString {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING ");
		String str=ip.nextLine();
		StringBuilder sb=new StringBuilder();
		
//		for(int i=0;i<str.length();i++)
//		{
//			char c=str.charAt(i);
//			int index=str.indexOf(c, i+1);// check the presence of character from i+1 index if present returns the first occurance index
//			if(index==-1)
//			{
//				sb.append(c);
//			}
//		}
//		System.out.println(sb);
		
		
		for(int i=0;i<str.length();i++)
		{
			boolean repeated=false;
			for(int j=i+1;j<str.length();j++)
			{
				if(str.charAt(i)==str.charAt(j))
					repeated=true;
					
			}
			if(!repeated)
				sb.append(str.charAt(i));
		}
		System.out.println(sb);
	}

}
