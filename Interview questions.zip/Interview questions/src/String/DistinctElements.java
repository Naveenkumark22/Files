package String;

import java.util.Arrays;
import java.util.Scanner;

public class DistinctElements {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			
			System.out.println("ENTER SIZE");
			int size=ip.nextInt();
			int [] s=new int [size];
			for(int i=0;i<size;i++)
			{
				s[i]=ip.nextInt();
				
			}
			int c=0;
			for(int i=0;i<size;i++)
			{
				for(int j=i+1;j<size;j++)
				{
					if(s[i]==s[j])
						c++;
					System.out.println(s[i]);
				}
			}
			
			for(int i=0;i<size;i++)
			{
		
			//	System.out.println(unique[i]);
			}
			
	}

}
