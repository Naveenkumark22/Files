package String;

import java.util.Scanner;

public class StringArrayContainsOnlyTheElementInWord {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		 String[] ar = new String [size];
		 System.out.println("ENTER THE ELEMENTS");
		int ans=0;
		 for(int i=0;i<size;i++)
		 {
			 ar[i]=ip.next();
		 }
		 System.out.println("ENTER THE WORD");
		 String word=ip.next();
		// System.out.println(word);
				 
		 int count = 0;
	        for(int i=0;i<ar.length;i++)
	        {
	        	String s=ar[i];
	        	//System.out.println(s);
	        	for(int j=0;j<word.length();j++ )
	        	{
	        		
	        		String w= Character.toString(word.charAt(j));
	        		//System.out.println(w);
	        		if(s.contains(w))
	        			count++;
	        	}
	        	if(count!=0)
	        		ans++;
	        	count=0;
	        }
	        System.out.println("------COUNT---------");
	        System.out.println(ans);
	}

}
//a","abc","bc","d