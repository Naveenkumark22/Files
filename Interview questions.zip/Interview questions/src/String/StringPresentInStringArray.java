package String;

import java.util.Scanner;

public class StringPresentInStringArray {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		 String[] ar = new String [size];
		 System.out.println("ENTER THE ELEMENTS");
		
		 for(int i=0;i<size;i++)
		 {
			 ar[i]=ip.next();
		 }
		 
		 
		 System.out.println("ENTER THE WORD");
		 String word=ip.next();
				 
		 int count = 0;
	        for(int i=0;i<ar.length;i++)
	        {
	        	
	            if(word.contains(ar[i]))
	                count++;
	        }
	        System.out.println(count);
	}

}
//a","abc","bc","d