package String;
//INPUT 1--ABCD
//INPUT  2--DCAB
//THE CHARACTERS SHOULD BE SAME IN BOTH STRINGS

import java.util.Scanner;

public class RotationOfString {

	public static void main(String[] args) {
		int i,j,count=0;
		Scanner ip=new Scanner(System.in);
		System.out.println();
		String str1=ip.nextLine();
		String str2=ip.next();
		if(str1.length()!=str2.length())
			System.out.println("FALSE");
		for(i=0;i<str1.length();i++)
		{
			for(j=0;j<str2.length();j++)
			{
				if(str1.charAt(i)==str2.charAt(j))
				{
					count++;
				}
			}
		}
		if(count==str1.length())
		{
			System.out.println("YES");
		}
		else
			System.out.println("FALSE");
		
	}

}
