package String;


import java.util.*;
class NumberOfCharactersToRemoveToMakeStringPalindrome {
    public static void main(String args[] ) throws Exception {
       Scanner ip=new Scanner(System.in);
       int n=ip.nextInt();
       int arr[]=new int[n];
       String s="";
       for(int i=0;i<n;i++)
       {
           arr[i]=ip.nextInt();
          
       }
       TreeSet<Integer> t=new TreeSet<Integer>();
        ArrayList<Integer> d=new ArrayList<Integer>();
      for(int i=0;i<n;i++)
      {
          int num=arr[i];
          while(num!=0)
          {
              int rem=Math.abs(num%10);

                t.add(rem);
                d.add(rem);
                num=num/10;

          }

      }
      ArrayList<Integer> freq=new ArrayList<Integer>();
       ArrayList<Integer> tl=new ArrayList<Integer>(t);
      int count=0;
     for(int i=0;i<tl.size();i++)
     {
         for(int j=0;j<d.size();j++)
         {
             if(tl.get(i)==d.get(j))
             {
                    count++;
             }
         }
         freq.add(count);
         count=0;

     }
    //  System.out.println(tl);
    //  System.out.println(freq);
     int min=Collections.min(freq);
     int index=freq.indexOf(min);
     int element=tl.get(index);
     System.out.println(element);


    }
}
