package String;

import java.util.Scanner;

public class ConsecutiveCharactersCount {

	public static void main(String[] args) {
		  Scanner ip=new Scanner(System.in);
		  
		  String s=ip.nextLine();
		  
		  int c=1;
	        
	        int max=1;
	        
	        for(int i=1;i<s.length();i++)
	        {
	            
	           if(s.charAt(i)==s.charAt(i-1))
	           {
	               c++;
	           }
	            
	            else
	            {
	                max=Math.max(c,max);
	                c=1;
	            }
	                
	                
	            
	            
	        }
	        max=Math.max(c,max);
	        System.out.println(max);
	}

}


//
//Input: s = "leetcode"
//Output: 2
//Explanation: The substring "ee" is of length 2 with the character 'e' only.
