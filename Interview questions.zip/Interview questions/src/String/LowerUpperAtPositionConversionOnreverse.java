package String;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class LowerUpperAtPositionConversionOnreverse {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		
		int t1=ip.nextInt();
	       int t2=ip.nextInt();
	       int n=ip.nextInt();
	       ArrayList<Integer> v=new ArrayList<>();
	       for(int i=0;i<n;i++)
	       {
	    	   v.add(ip.nextInt());
	       }
	       Collections.sort(v);
	       System.out.println(v);
	       
	       ArrayList<Integer> a=new ArrayList<>();
	       ArrayList<Integer> b=new ArrayList<>();
	       int c1=0;
	       int c2=0;
	       int j=t1*v.get(n-1);
	       int k=0;
	       a.add(v.get(n-1));
	       c1++;
	       for(int i=n-2;i>=0;i--)
	       {
	    	   int x=j+(t1*v.get(i));
	    	   int y=k+(t2*v.get(i));
	    	   if(x<y)
	    	   {
	    		   a.add(v.get(i));
	    		   c1++;
	    		   y=y-(t2*v.get(i));
	    		   if(x<y)
	    		   {
	    			   j=0;
	    			   k=y-x;
	    		   }
	    		   else
	    		   {
	    			   k=0;
	    			   j=x-y;
	    		   }
	    	   }
	    	   else
	    	   {
	    		   x=x-(t1*v.get(i));
	    		   b.add(v.get(i));
	    		   c2++;
	    		   if(x<y)
	    		   {
	    			   j=0;
	    			   k=y-x;
	    		   }
	    		   else
	    		   {
	    			   k=0;
	    			   j=x-y;
	    		   }
	    	   }
	       }
	       System.out.println(a);
	       System.out.println(b);
	       for(int i=0;i<c1;i++)
	       {
	    	   System.out.print(a.get(i)+" ");
	       }
	       System.out.println();
	       for(int i=0;i<c2;i++)
	       {
	    	   System.out.print(b.get(i)+" ");
	       }
	       
		
		
		
		
//		String s=ip.nextLine();
//		ArrayList<Integer> arr=new ArrayList<Integer>();
//		for(int i=0;i<s.length();i++)
//		{
//			char c=s.charAt(i);
//			if(c>=97&&c<=123)  //lower case
//			{
//				arr.add(0);
//			}
//			
//			if(c>=65&&c<=96)  //lower case
//			{
//				arr.add(1);
//			}
//		}
//		StringBuffer sb=new StringBuffer(s.toLowerCase());
//		sb=sb.reverse();
//		StringBuffer ans=new StringBuffer();
//		for(int i=0;i<sb.length();i++)
//		{
//			if(arr.get(i)==1)
//			{
//				ans.append(Character.toUpperCase(sb.charAt(i)));
//			}
//			else
//			{
//				ans.append(sb.charAt(i));
//			}
//			
//		}
//		System.out.println(ans.toString());

	}

}
