package String;

import java.util.Scanner;

public class MinimumAddtoMakeParenthesesValid {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE  PARANTHESES STRING");
		String str=ip.next();
		int left=0,right=0;
		for(int i=0;i<str.length();i++)
		{
			//if the paranthese is open
			if(str.charAt(i)=='(')
				left++;
			//if parantheses is closed and has the open parantheses ')'
			else if(left>0)
			{
				left--;
				
			} 
			//we want closed paranthees
			else
				right++;
		}
		System.out.println(left+right);
	}

}
