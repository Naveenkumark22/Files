package String;
import java.util.Scanner;

public class UserStringInput {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		 String[] ar = new String [size];
		 System.out.println("ENTER THE ELEMENTS");
		 for(int i=0;i<size;i++)
		 {
			 ar[i]=ip.next();
		 }
		 for(int i=0;i<size;i++)
		 {
			System.out.println(ar[i]);
		 }
	}

}
