package String;

import java.util.Scanner;

public class SubstringOfString {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str=ip.next();
		for(int i=0;i<str.length();i++)
		{
			for(int j=i+1;j<=str.length();j++)//this loop for end 
			{
				//i for starting position
				//j for ending postion
				System.out.println(str.substring(i, j));
			}
		}
	}

}
