package String;

import java.util.Scanner;

public class RunningEncoding {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str=ip.next();
		char ch[]=new char[str.length()];
		for(int i=0;i<str.length();i++)
			
		{
			ch[i]=str.charAt(i);
		}
		
		for(int i=0;i<ch.length;)
		{
			int count=1;
			for(int j=i+1;j<ch.length;j++)
			{
				
				if(ch[i]==ch[j])
				{
					
					count++;
					
				}
				else 
					break;
				
			}
			System.out.print(ch[i]);
			System.out.print(count);
			i=i+count;
			
		}
		
	}

}
