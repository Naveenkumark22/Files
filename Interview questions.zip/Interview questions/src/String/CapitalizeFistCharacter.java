package String;

class Solution {
    public String capitalizeTitle(String title) {
     //   String[] str=title.split(" ");
        String str=title.toLowerCase();
        String[] s=str.split(" ");
        String ans="";
        for(int i=0;i<s.length;i++)
        {
            String in=s[i];
            if(in.length()>2)
                {
                    String first=in.substring(0,1).toUpperCase();
                    String rem=in.substring(1,in.length()).toLowerCase();
                    String append=first+rem;
                    ans+=append+" ";
                    
                }
                else if(in.length()<=2){
                ans=ans+in+" ";
                }
            
           
        }
        return ans.trim();
        
    }
}