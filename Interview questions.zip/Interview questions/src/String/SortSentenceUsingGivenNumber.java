package String;

import java.util.Scanner;

public class SortSentenceUsingGivenNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE STRING ");
		String s=ip.nextLine();
		StringBuilder sb=new StringBuilder();
		String str[]=s.split(" ");
        String res[]=new String[str.length+1];
        String ret="";
        for(int i=0;i<str.length;i++){
            int inx=Character.getNumericValue(str[i].charAt(str[i].length()-1));
           res[inx]=str[i].substring(0,str[i].length()-1);
           
        }
        for(int j=1;j<res.length;j++)
           ret+=(j==res.length-1)?res[j]:res[j]+" ";
            System.out.println(ret);
	    
	}

}
