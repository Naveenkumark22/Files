package String;

import java.util.*;


class LongestSequenceOfSameCharacterInString {
    public static void main(String args[] ) throws Exception {
       Scanner ip=new Scanner(System.in);
       String s=ip.next();
       int max=Integer.MIN_VALUE;
       int count=1;
       for(int i=0;i<s.length()-1;i++)
       {
           int j=i;
            while( j+1<s.length() &&  s.charAt(j)==s.charAt(j+1))
           {
               count++;
               j++;
           }
          
               max=Math.max(max,count);
               count=1;
           
       }
       System.out.println(max);

    }
}
//
//   input -->aaaaabbccc
//  output---->5   here a occurs 5 times so ans is 5
