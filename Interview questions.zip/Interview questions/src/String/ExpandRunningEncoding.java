package String;

import java.util.Scanner;

public class ExpandRunningEncoding {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str=ip.next();
		int length=str.length();
		char word[]=new  char[length/2];
		int num[]=new int[length/2];
		int t=0;
		int s=0;
		for(int i=0;i<length;i++)
		{
			
			if(i%2==0)
			{
				
				word[t]=str.charAt(i); 
				t++;
			}
			else if(i%2!=0)
			{
				int  n=Integer.parseInt(str.charAt(i)+"");
				num[s++]=n;
				
			}
			
		}
//		for(int i=0;i<num.length;i++)
//		{
//			System.out.println(num[i]);
//		}
		String ans="";
		for(int i=0;i<num.length;i++ )
		{
			
			for(int j=0;j<num[i];j++)
			{
			   ans=ans+word[i];
						
			}
			
		}
		System.out.println(ans);
		
	}

}
