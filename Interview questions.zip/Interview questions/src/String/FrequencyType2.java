package String;

import java.util.Scanner;

public class FrequencyType2 {
	public static void main(String args[] ) throws Exception {


	       Scanner ip=new Scanner(System.in);
	     int n=ip.nextInt(); 
	       String s=ip.next();
	       int k=ip.nextInt();
	       for(int i=0;i<s.length();i++)
	       {
	           int temp=s.charAt(i)+k;
	           if(s.charAt(i)>='a'&&s.charAt(i)<='z')	
	           {
	            
	                while(temp>122)
	                    temp-=26;
	                System.out.print((char)(temp));
	           }
	           else if(s.charAt(i)>='A'&&s.charAt(i)<='Z')
	           {
	           
	                while(temp>90)
	                    temp-=26;
	                    System.out.print((char)(temp));
	           }
	            else
	                System.out.print(s.charAt(i));


	           
	           
	       }
	    }
}
