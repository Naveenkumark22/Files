package String;
//php  mysql c java

import java.util.Arrays;
import java.util.Scanner;  
public class SortStringArrayExample1  
{  
public static void main(String args[])   
{  
//defining an array of type String  
	Scanner ip=new Scanner(System.in);
	System.out.println("ENTER SIZE");
	int s=ip.nextInt();
	int i,j;
	System.out.println("ENTER ARRAY ELEMENTS");
	String [] a=new String[s];
	for(i=0;i<s;i++) {
		a[i]=ip.next();
		
	}
	String temp;
	for(i=0;i<s;i++)
	{
		for(j=i+1;j<s;j++)
			
		{
			if(a[i].compareTo(a[j])>0)  
			{
				temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
		}
	}
	for(i=0;i<s;i++)
	{
		System.out.println(a[i]);
	}
	
//logic for sorting   

}  
}  