package String;
//print first letter of string 


import java.util.Scanner;

public class FirstLetterOfString {

	public static void main(String[] args) {
		int i,j;
		int start=0;
		System.out.println("ENETER THE STRING");
		Scanner ip=new Scanner(System.in);
		String str=ip.nextLine();
		
		//for priting first letter
		System.out.print(str.charAt(start));
		for(i=0;i<str.length();i++)
		{
			if(str.charAt(i)==' ')
			{
				System.out.print(str.charAt(i+1));
			}
			//start++;
			
		}
			
	}

}
