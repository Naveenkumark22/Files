package Numbers;

import java.util.ArrayList;
import java.util.Scanner;

public class SquareFreeNumber {
	
	

public static void main(String args[]) {
        Scanner ip=new Scanner(System.in);
        int n=ip.nextInt();
        ArrayList<Integer> list=new ArrayList<Integer>();
        ArrayList<Integer> sq=new ArrayList<Integer>();
        ArrayList<Integer> ans=new ArrayList<Integer>();
        for(int i=2;i<=n;i++)
        {
            if(n%i==0)
            {
                list.add(i);;
            }
        }
       // System.out.println(list);
        for(int i=2;i<=n;i++)
        {
            int sqrt=i*i;
            if(sqrt>n)
            {
                break;
            }
            sq.add(sqrt);
        }
       //  System.out.println("sq"+sq);
       //  list.removeAll(sq);
         // System.out.println("li"+list);
          
        for(int i=0;i<list.size();i++)
        {
            int c=0;
            for(int j=0;j<sq.size();j++)
            {
                if(list.get(i)%sq.get(j)==0)
                {
                    c++;
                    // System.out.print(list.get(i)+"  ");
                    //   list.remove(list.get(i));
                      break;
                }
   
            }

            if(c==0)
             ans.add(list.get(i));
          
        //     if(c>0){
        // //System.out.println(list.get(i));
        //     list.remove(list.get(i));
        //     }
        }
       //  System.out.println(list);
        System.out.println(ans.size());
    }
}


	
