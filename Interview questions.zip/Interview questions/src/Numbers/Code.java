package Numbers;

/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Code
{
	public static void main (String[] args) throws java.lang.Exception
	{
        
        Scanner ip=new Scanner(System.in);
        int num=ip.nextInt();
        int e=ip.nextInt();
        int ans=0;
        System.out.println(e);
        while(num!=e)
        {
            System.out.println(num);
            int c=0;
            int d=0;
            int n=num;
            int rem=0;
            int temp=num;
            int div=1;
            while(n!=0)
            {
                 rem=n%10;
                 if(rem!=0) {
                div=temp%rem;
                 }
                if(div==0)
                {
                    d++;
                }
                n=n/10;
                c++;
            }
            if(c==d)
            {
                ans++;
                System.out.println(num);
            }
            num++;
        }
        System.out.println(ans);
    	}
}
