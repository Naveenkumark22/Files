package Numbers;

import java.util.Scanner;

public class ConsecutiveSum {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			int n=7;
			int a[]=new int[]{2,3,5,7,11,13,17};
			int sum;
			int c=0;
		for(int i=a.length-1;i>=0;i--)
		{
			sum=0;
			
			for(int j=i-1;j>=0;j--)
				
			{
				sum+=a[j];
				while(sum==a[i]&&sum!=a[j])
				{
					if(sum==a[i]) {
						c++;
						break;
						//System.out.println(a[i]);
				}
				
			}
			//System.out.println(sum+"   "+a[i]);
//			if(sum==a[i]) {
//				c++;
//				System.out.println(a[i]);
//			}
		}
		System.out.println(c);
			
	}
	}
}
