//Input: arr = [1,2,2,3,3,3]
//Output: 3
//Explanation: 1, 2 and 3 are all lucky numbers, return the largest of them.
//No lucky number means return -1;
// return +2 max


package Numbers;

import java.util.Scanner;

public class LuckyNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER ARRAY SIZE");
		int size=ip.nextInt();
		int arr[]=new int[size];
		int sumarr[]=new int[size];
		int sum=0;
		int freq[]=new int[arr.length];
		System.out.println("ENTER ARRAY ELEMENTS");
		for(int i=0;i<size;i++)
		{
			arr[i]=ip.nextInt();	
			 freq[i]=-1;
		}
		 
	        
	        int count;
	        for(int i=0;i<arr.length;i++)
	        {
	            count=1;
	            for(int j=i+1;j<arr.length;j++)
	            {
	                if(arr[i]==arr[j])
	                {
	                    count++;
	                    freq[j]=0;
	                }
	            }
	            if(freq[i]!=0)
	            {
	                freq[i]=count;
	            }
	                
	        }
	        int max=0;
	        int c=0;
	        for(int i=0;i<arr.length;i++)
	        {
	            if(freq[i]==arr[i]&&freq[i]!=0)
	            {
	                if(arr[i]>max)
	                {
	                    max=arr[i];
	                    c++;
	                }
	            }
	           
	        }
	            
	        if(c>0)
	        System.out.println(max);
	        else
	        	System.out.println("-1");
	}

}
