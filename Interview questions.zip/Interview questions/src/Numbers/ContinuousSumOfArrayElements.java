package Numbers;

import java.util.Scanner;

public class ContinuousSumOfArrayElements {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			System.out.println("ENTER ARRAY SIZE");
			int size=ip.nextInt();
			int arr[]=new int[size];
			int sumarr[]=new int[size];
			int sum=0;
			System.out.println("ENTER ARRAY ELEMENTS");
			for(int i=0;i<size;i++)
			{
				arr[i]=ip.nextInt();
				sum+=arr[i];
				sumarr[i]=sum;
			}
			System.out.println("ANSWER");
			for(int i=0;i<size;i++)
			{
				System.out.println(sumarr[i]);
			}
			
	}

}
