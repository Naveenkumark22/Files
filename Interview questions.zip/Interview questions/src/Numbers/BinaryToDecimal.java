package Numbers;

import java.util.Scanner;

public class BinaryToDecimal {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENETR THE BINARY  NUMBER");
		int bnum=ip.nextInt();
		int binary;
		int decimal=0,n=0;
		while(true)
		{
			if(bnum==0)
				break;
			else
			{
			int temp=bnum%10;
			decimal+=temp*Math.pow(2, n);
			bnum/=10;
			n++;
				
			}
		}
		System.out.println(decimal);
	}

}
