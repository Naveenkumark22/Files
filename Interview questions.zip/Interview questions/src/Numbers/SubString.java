package Numbers;

import java.util.Scanner;

public class SubString {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE RANGE NUMBER");
		int range=ip.nextInt();
		String binary=Integer.toBinaryString(range);
		System.out.println(binary);
		System.out.println(binary.length());
		for(int i=0;i<=binary.length()-3;i++)
		{
			String s=binary.substring(i,i+3);
			System.out.println(s);
		}
	}

	
}
