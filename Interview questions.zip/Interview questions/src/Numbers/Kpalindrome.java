package Numbers;


import java.util.Scanner;

class Kpalindrome {
    public static void main(String args[] ) throws Exception {
        Scanner ip=new Scanner(System.in);
        String s=ip.nextLine();
        int k=ip.nextInt();
        char arr[]=new char[s.length()];
        int freq[]=new int[s.length()];
        for(int i=0;i<s.length();i++)
        {
            arr[i]=s.charAt(i);
            freq[i]=-1;
        }
        int l=s.length();
        int count=1;
        for(int i=0;i<l;i++)
        {
            count=1;
            for(int j=i+1;j<l;j++)
            {
                if(arr[i]==arr[j])
                {
                    count++;
                    freq[j]=0;
                }
            }
            if(freq[i]!=0)
            {
                freq[i]=count;
            }

        }
        int ans=0;
        for(int i=0;i<l;i++)
        {
            if(freq[i]!=0&&freq[i]%2!=0)
            {
                    ans++;
            }
        }
        if(ans==k||ans-k==1)
        {
            System.out.println("Yes");
        }
        else
         System.out.println("No");
    }
}

