package Numbers;

import java.util.Scanner;

public class MaxAscendingSum {

	public static void main(String[] args) {
		 Scanner ip=new Scanner(System.in);
	       int n=ip.nextInt();
	       int nums[]=new int[n];
	       String s="";
	       for(int i=0;i<n;i++)
	       {
	           nums[i]=ip.nextInt();
	          
	       }
		int sum = nums[0], maxSum = nums[0];
		
        for (int i = 1; i < nums.length; i++) {
        
        	
        	if (nums[i] <= nums[i - 1])  //if next element is small make sum=0
        	{
            sum = 0;
        	}
          
          sum += nums[i];
          maxSum = Math.max(maxSum, sum);
        }
        System.out.println(maxSum);

	}

}

//
//Input: nums = [10,20,30,5,10,50]
//Output: 65
//Explanation: [5,10,50] is the ascending subarray with the maximum sum of 65.