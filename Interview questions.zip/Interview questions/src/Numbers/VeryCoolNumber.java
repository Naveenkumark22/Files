package Numbers;

import java.util.Scanner;

public class VeryCoolNumber {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			System.out.println("ENTER THE RANGE NUMBER");
			int range=ip.nextInt();
			System.out.println("ENTER NUMBER OF COOL WANT");
			int numberofcool=ip.nextInt();
			int cool;
			int verycool=0;
			for(int i=1;i<=range;i++)
			{
				cool=0;
				String binary=Integer.toBinaryString(i);
				System.out.println("NUMBER    BINARYNUMBER");
				System.out.println(i +"   "+binary);
				for(int j=0;j<=binary.length()-3;j++)
				{
					if(binary.substring(j, j+3).equals("101"))
					{
						cool++;
					}
					
				}
				if(cool>=numberofcool)
					
				{
					verycool++;
				}
			}
			System.out.println("ANS");
			System.out.println(verycool);
	}

}
