//Input: num = 38
//Output: 2
//Explanation: The process is
//38 --> 3 + 8 --> 11
//11 --> 1 + 1 --> 2 
//Since 2 has only one digit, return it.

package Numbers;

import java.util.Scanner;

public class AddDigits {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER NUMBER");
		int num=ip.nextInt();
		while(num>=0)
		{
			if(num>=0&&num<=9) {
				System.out.println("OUTPUT");
				System.out.println(num);
				break;
			}
			else {
				int sum=0,rem;
				while(num!=0)
				{
					rem=num%10;
					sum+=rem;
					num=num/10;
					
				}
				num=sum;
				
			   }
			
		}
		
	}

}
