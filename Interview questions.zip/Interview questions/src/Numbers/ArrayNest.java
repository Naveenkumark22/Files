package Numbers;


import java.util.*;


class ArrayNest{
    public static void main(String args[] ) throws Exception {
       Scanner ip=new Scanner(System.in);
       int n=ip.nextInt();
       int arr[]=new int[n];
       int max=Integer.MIN_VALUE;
       for(int i=0;i<n;i++)
       {
           arr[i]=ip.nextInt();
       }
       
       for(int i=0;i<n;i++ )
       {
           ArrayList<Integer> t=new ArrayList<Integer>();
           t.add(arr[i]);
           for(int j=i;j<n;j++ )
           {
               if(!t.contains(arr[t.get(t.size()-1)]))
               t.add(arr[t.get(t.size()-1)]);
           }
           max=Math.max(t.size(),max);
           System.out.println(t);
       }
       System.out.println(max);

    }
}

