package Numbers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Scanner;

public class Evenadd {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		int n=ip.nextInt();
		ArrayList<Integer> odd=new ArrayList<>();
		ArrayList<Integer> even=new ArrayList<>();
		for(int i=0;i<n;i++)
		{
			int num=ip.nextInt();
			if(num%2==0)
			{
				even.add(num);
				
			}
			else
				odd.add(num);
		}
		Collections.sort(even);
		Collections.sort(odd);
		ArrayList<Integer> ans=new ArrayList<>();
		int min=Math.min(even.size(),odd.size());
		int i;
		for( i=0;i<min;i++)
		{
			ans.add(odd.get(i));
			ans.add(even.get(i));
		}
		while(i<even.size())
		{
			ans.add(even.get(i));
			i++;
		}
		while(i<odd.size())
		{
			ans.add(odd.get(i));
			i++;
		}
		
		System.out.println(ans);
       
	}

}
