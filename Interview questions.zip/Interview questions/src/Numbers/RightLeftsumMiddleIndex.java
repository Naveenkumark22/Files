package Numbers;

import java.util.Scanner;

public class RightLeftsumMiddleIndex {

	public static void main(String[] args) {
		int len;
		 Scanner scan = new Scanner(System.in);
		System.out.println("Enter Length of the array : ");
	       len = scan.nextInt();
		   int arr[]=new int[len];
	       System.out.println("Enter elements in the array : ");
	       int totalsum=0;
	       for(int i=0; i<len; i++)
	       {
	           arr[i] = scan.nextInt();
	           totalsum+=arr[i];
	       }
	       int left=0;
	       
	       for(int i=0;i<len;i++)
	       {
	    	   if(left==totalsum-arr[i])
	    		   System.out.println("index  "+i+"     element  "+arr[i]);
	    	   left+=arr[i];
	    	   totalsum-=arr[i];
	    	   
	       }
	       
	       
	       
	}		

}
