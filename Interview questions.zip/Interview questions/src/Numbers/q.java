package Numbers;


import java.util.*;


class q {
    public static void main(String args[] ) throws Exception {


       Scanner ip=new Scanner(System.in);
      //int n=ip.nextInt(); 
       System.out.println("ENTER THE STRING");
       String s=ip.next();
       System.out.println("ENTER THE KEY");
       int k=ip.nextInt();
       for(int i=0;i<s.length();i++)
       {
           int temp=s.charAt(i)+k;
           if(s.charAt(i)>='a'&&s.charAt(i)<='z')
           {
            //    char c;
            //    int num=0;
            //    num=(num*10)+(s.charAt(i)-'a');
            //    System.out.print((char)('a'+num+k));
                
                while(temp>122)
                    temp-=26;
                System.out.print((char)(temp));
           }
           else if(s.charAt(i)>='A'&&s.charAt(i)<='Z')
           {
            //    char c;
            //    int num=0;
            //    num=(num*10)+(s.charAt(i)-'A');
                while(temp>90)
                    temp-=26;
                    System.out.print((char)(temp));
           }
            else
                System.out.print(s.charAt(i));


           
           
       }
    }
}
