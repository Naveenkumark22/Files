package Numbers;

import java.util.Scanner;

public class PrimeNumberWithintheRange {

	public static void main(String[] args) {
			Scanner ip=new Scanner(System.in);
			System.out.println("ENTER THE NUMBER");	
			int arr[]=new int[10];
			int start=ip.nextInt();
			int end=ip.nextInt();
			int count;
			int k=0;
			while(start<end)
			{
				count=0;
				
				for(int i=2;i<=start/2;i++)
				{
					if(start%i==0)
					{
						count=1;
						break;
					}
				}
				if(count==0)
					//arr[k++]=start;
				System.out.println(start);
				start++;
			}
			//System.out.println(arr);
			
	}

}
