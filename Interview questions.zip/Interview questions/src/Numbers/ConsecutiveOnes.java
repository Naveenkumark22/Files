package Numbers;

import java.util.Scanner;

public class ConsecutiveOnes {

	public static void main(String[] args) {
		   Scanner ip=new Scanner(System.in);
		   int n=ip.nextInt();
	       int nums[]=new int[n];
	       String s="";
	       for(int i=0;i<n;i++)
	       {
	           nums[i]=ip.nextInt();
	          
	       }
	       
	       int c=0;
	        int max=0;
	        for(int i=0;i<nums.length;i++)
	        {
	            if(nums[i]==1){
	                c++;
	            }
	            else
	            {
	                max=Math.max(c,max);
	                c=0;
	            }
	        }
	        max=Math.max(c,max);
	        System.out.println(max);
	}

}

//Input: nums = [1,1,0,1,1,1]
//Output: 3
//Explanation: The first two digits or the last three digits are consecutive 1s. The maximum number of consecutive 1s is 3.