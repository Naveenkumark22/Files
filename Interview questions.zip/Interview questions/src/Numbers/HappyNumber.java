package Numbers;

/*
input: n = 19
Output: True
19 is Happy Number,
1^2 + 9^2 = 82
8^2 + 2^2 = 68
6^2 + 8^2 = 100
1^2 + 0^2 + 0^2 = 1
As we reached to 1, 19 is a Happy Number.

 */


import java.util.ArrayList;
import java.util.Scanner;

public class HappyNumber {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		ArrayList<Integer> a=new ArrayList<Integer>();
		System.out.println("ENTER THE NUMBER");
		int num=ip.nextInt();
		int temp,rem;
		int sum=0;
		while(num!=1)
			
		{
//			
			sum=0;
			temp=num;
			while(temp!=0)
			{
				rem=temp%10;
				sum+=rem*rem;
				temp/=10;
				}
				
				if(a.contains(sum)) {
					System.out.println("false");
					break;
				
			}
			
			
			num=sum;
			a.add(sum);
		}
		
		if(num==1)
		System.out.println("true");
		
		
	}

}





