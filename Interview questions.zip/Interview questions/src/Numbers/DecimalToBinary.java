package Numbers;

import java.util.Scanner;

public class DecimalToBinary {

	public static void main(String[] args) {
				
		Scanner ip=new Scanner(System.in);
		System.out.println("ENETR THE DECIMAL NUMBER");
		int num=ip.nextInt();
		int ar[]=new int[20];
		int index=0;
		while(num>0)
		{
			ar[index++]=num%2;
			num/=2;
			
		}
		for(int i=index-1;index>=0;index-- )
			System.out.print(ar[index]);
	}

}

//int binary=Integer.toBinary(num);