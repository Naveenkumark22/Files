package Numbers;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SortByFrequency {

	public static void main(String[] args) {
		int[] arr= {1,1,3,4,2,5} ;
		int[] res=new int[arr.length]; 
			Map<Integer,Integer> map=new HashMap<Integer,Integer>();
			for(int i=0;i<10;i++) {
				map.put(i, 0);
			}
			for(int i=0;i<arr.length;i++) {
				if(arr[i]==0)
					continue;
				int c=1;
				for(int j=i+1;j<arr.length;j++) {
					if(arr[i]==arr[j]) {
						c++;
						arr[j]=0;
					}
					
				}
				map.replace(arr[i], c);
			}
			for(int i=0;i<=9;i++) {
//				if(map.remove(key))
				map.remove(i, 0);
			}
//			for(Map.entry(<Integer>,<Integer>) i:map.entrySet()) {
//				
//			}
			int k=0;
			Iterator <Integer> it = map.keySet().iterator();       //keyset is a method  
			while(it.hasNext())  
			{  
			int key=(int)it.next();
			for(int i=0;i<map.get(key);i++) {
				res[k++]=key;
			}
//			System.out.println("Roll no.: "+key+"     name: "+map.get(key));  
			}  
			
			for(int i=0;i<res.length;i++) {
				System.out.println(res[i]);
			}
	}

}
