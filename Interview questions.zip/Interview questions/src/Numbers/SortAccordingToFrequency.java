package Numbers;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

class SortAccordingToFrequency {
    public static void main(String args[] ) throws Exception {
        
        Scanner ip=new Scanner(System.in);
        int n1=ip.nextInt();
        ArrayList<Integer> a=new ArrayList<Integer>();
        ArrayList<Integer> freq=new ArrayList<Integer>();
        
        for(int i=0;i<n1;i++)
        {
            a.add(ip.nextInt());
            
        }
         int n2=ip.nextInt();
        ArrayList<Integer> b=new ArrayList<Integer>();
         for(int i=0;i<n2;i++)
        {
            b.add(ip.nextInt());
        }

        a.addAll(b);


        TreeSet<Integer> t=new TreeSet<Integer>();
         for(int i=0;i<a.size();i++)
        {
           t.add(a.get(i));
        }

        ArrayList<Integer> unique=new ArrayList<Integer>(t);


     
        
         ArrayList<Integer> d=new ArrayList<Integer>();
        for(int i=0;i<unique.size();i++)
        {
            int c=0;
            for(int j=0;j<a.size();j++)
            {
                if(unique.get(i)==a.get(j))
                {
                    c++;
                }

            }
            d.add(c);

        }
       int max=Integer.MIN_VALUE;


        for(int i=0;i<d.size();i++)
        {
            max=Math.max(max,d.get(i));
        }
        // System.out.println(unique);
        // System.out.println(d);

         for(int i=max;i>0;i--)
         {
             
                for(int j=0;j<d.size();j++)
                {
                    if(d.get(j)==i)
                    {
                        for(int k=0;k<i;k++)
                        {
                            System.out.print(unique.get(j)+" ");
                        }
                    }
                }
         }
    }
}

