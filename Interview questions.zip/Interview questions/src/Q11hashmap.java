//HASHMAP GETTING INPUT FROM USER


import java.util.*;
import java.util.Scanner.*;

public class Q11hashmap {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
	HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
	int i;
	for(i=0;i<2;i++)
	{
		char ch = ip.next().charAt(0);
		int num=ip.nextInt();
		hm.put(ch, num);
		
	}
	System.out.println(hm);
	}

}
