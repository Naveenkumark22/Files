import java.util.Scanner;

public class RightRotateArray {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		System.out.println("ENTER ELEMENTS");
		int ar[]=new int[size];
		for(int i=0;i<size;i++)
		{
			
			ar[i]=ip.nextInt();
		}
		int length=size;
		int j, last;    
        //Stores the last element of the array    
        last = ar[length-1];    
        
        for(j = length-1; j > 0; j--){    
            //Shift element of array by one    
            ar[j] = ar[j-1];    
        }    
        //Last element of array will be added to the start of array.    
        ar[0] = last;    
    
        
	for(int i=0;i<size;i++)
	{
		System.out.println(ar[i]);
	}
	
}
}