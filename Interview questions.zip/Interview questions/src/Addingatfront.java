// SEPARATE NEGATIVE ELMENTS IN ONE ARRAY AND PUT POSITIV ELEMENTS IN  ANOTHER ARRAY AND MERGE TWO ARRAYS




/* USING LINKEDLIST 
 * TO ADD AT FIRST AND LAST 
 * import java.util.LinkedList;   ----->    addfirst()  ,addlast()
public class Main {
  public static void main(String[] args) {
    LinkedList<String> cars = new LinkedList<String>();
    cars.add("Volvo");
    cars.add("BMW");
    cars.add("Ford");
    
    // Use addFirst() to add the item to the beginning
    cars.addFirst("Mazda");
    System.out.println(cars);
  }
}

 */


import java.util.ArrayList;

public class Addingatfront  {
 
    public static void main(String[] args) {
        
        //create new ArrayList
        ArrayList<String> aListNumbers 
                = new ArrayList<String>();
        
        //we are going to add some numbers to ArrayList
        aListNumbers.add("One");
        aListNumbers.add("Two");
        aListNumbers.add("Three");
        
        /*
         * To insert element at beginning of ArrayList
         * use add method of ArrayList class with index 0
         */
        
        
        aListNumbers.add(0, "Zero");
        aListNumbers.add(1, "Zero");
        System.out.println("Element added at beginning of ArrayList");
        
        //print ArrayList
        System.out.println(aListNumbers);
    }
}