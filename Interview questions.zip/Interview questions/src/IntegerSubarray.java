import java.util.Scanner;

public class IntegerSubarray {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		System.out.println("ENTER THE SIZE");
		int size=ip.nextInt();
		int a[]=new int[size];
		for(int i=0;i<size;i++)
			
		{
			a[i]=ip.nextInt();
		}
		int sum=0;
        for(int i=0;i<a.length;i++)
        {
            for(int j=i+1;j<=a.length;j++)
            {
            	//if(j%2!=0) {
                for(int k=i;k<j;k++)
                {
                	//System.out.println("elements");
                	System.out.print(" element "+a[k]);
                    sum+=a[k];
                }
                System.out.println();
                System.out.println("sum "+sum);
            }//}
        }
	}

}
