import java.util.Scanner;

public class RemoveElementInArray {
  public static void main(String[] args) {
    Scanner ip = new Scanner(System.in);
    System.out.println("ENTER ARRAY SIZE:");
    int n=ip.nextInt();
    int[] intArr=new int[n];
    System.out.println("ENTER ARRAY ELEMENTS:");
    for(int i=0;i<n;i++)
    {
    	intArr[i]=ip.nextInt();
    }
    System.out.print("Enter Element to be deleted : ");
    int elem = ip.nextInt();
    int count=0;
    for(int i = 0; i < intArr.length; i++){
    	
    	//System.out.println(intArr[i]);
    	
      if(intArr[i] == elem)
      {
    	  count++;
    	  
    	  
    	 // System.out.println("in if"+intArr[i]);
        // shifting elements
    	  
    	  
        for(int j = i; j < intArr.length - 1; j++)//shifting elements
        {
        	
            intArr[j] = intArr[j+1];
           
        }
      
      }
    }
      
    System.out.println("Elements -- " );
    for(int i = 0; i < intArr.length-count; i++){
      System.out.print(" " + intArr[i]);
    }                
  }
}